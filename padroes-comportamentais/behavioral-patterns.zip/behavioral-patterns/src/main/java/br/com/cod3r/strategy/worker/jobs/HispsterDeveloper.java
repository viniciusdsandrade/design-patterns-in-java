package br.com.cod3r.strategy.worker.jobs;

public class HispsterDeveloper implements Worker {

	@Override
	public void eat() {
		
	}

	@Override
	public void move() {
		
	}

	@Override
	public void work() {
		
	}

}
