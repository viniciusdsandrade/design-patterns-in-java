package br.com.cod3r.template.persist;

public class Client {

	public static void main(String[] args) {
		
	}
}
