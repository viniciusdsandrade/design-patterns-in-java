package br.com.cod3r.command.migration.commands;

public abstract class MigrationCommand {
	
}
