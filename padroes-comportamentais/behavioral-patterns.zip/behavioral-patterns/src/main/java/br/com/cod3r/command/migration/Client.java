package br.com.cod3r.command.migration;

public class Client {

	public static void main(String[] args) {
		
		
	}
}
