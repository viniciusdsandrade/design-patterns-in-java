package br.com.cod3r.template.sales.model;

public enum Category {
	ELETRONICS, CLOTHES, SPORTS;
}
