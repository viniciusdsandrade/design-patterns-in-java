package br.com.cod3r.strategy.worker.jobs;

public interface Worker {
	void eat();
	void move();
	void work();
}
