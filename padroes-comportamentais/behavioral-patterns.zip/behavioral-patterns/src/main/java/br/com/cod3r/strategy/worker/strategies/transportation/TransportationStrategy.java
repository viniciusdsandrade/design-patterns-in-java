package br.com.cod3r.strategy.worker.strategies.transportation;

public interface TransportationStrategy {
	void move();
}
