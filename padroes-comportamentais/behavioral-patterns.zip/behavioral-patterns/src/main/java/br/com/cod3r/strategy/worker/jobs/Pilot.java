package br.com.cod3r.strategy.worker.jobs;

public class Pilot implements Worker {

	@Override
	public void eat() {
		
	}

	@Override
	public void move() {
		
	}

	@Override
	public void work() {
		
	}

}
