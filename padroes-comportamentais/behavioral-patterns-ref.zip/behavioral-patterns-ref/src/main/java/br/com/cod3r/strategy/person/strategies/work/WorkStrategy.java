package br.com.cod3r.strategy.person.strategies.work;

public interface WorkStrategy {
	void work();
}
