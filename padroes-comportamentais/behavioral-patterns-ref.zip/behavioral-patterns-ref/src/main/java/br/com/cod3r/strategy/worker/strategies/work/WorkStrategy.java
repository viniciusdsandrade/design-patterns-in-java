package br.com.cod3r.strategy.worker.strategies.work;

public interface WorkStrategy {
	void work();
}
