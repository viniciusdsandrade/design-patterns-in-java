package br.com.cod3r.strategy.person.strategies.eat;

public interface EatStrategy {
	void eat();
}
