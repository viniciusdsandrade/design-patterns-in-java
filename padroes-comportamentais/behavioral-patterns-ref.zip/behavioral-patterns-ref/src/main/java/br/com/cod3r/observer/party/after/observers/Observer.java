package br.com.cod3r.observer.party.after.observers;

public interface Observer {
	void update(boolean status);
}
