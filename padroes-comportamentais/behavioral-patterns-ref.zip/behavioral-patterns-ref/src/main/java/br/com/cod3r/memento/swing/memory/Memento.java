package br.com.cod3r.memento.swing.memory;

public interface Memento {

}
