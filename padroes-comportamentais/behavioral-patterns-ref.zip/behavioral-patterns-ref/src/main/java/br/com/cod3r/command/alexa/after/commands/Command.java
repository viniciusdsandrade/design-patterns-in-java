package br.com.cod3r.command.alexa.after.commands;

public interface Command {
	void execute();
}
