package br.com.cod3r.command.alexa.after.lights;

public interface GenericLight {
	void turnOn();
	void turnOff();
}
