package br.com.cod3r.strategy.worker.strategies.eat;

public interface EatStrategy {
	void eat();
}
