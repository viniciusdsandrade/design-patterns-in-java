package br.com.cod3r.template.sales.after.model;

public enum Category {
	ELETRONICS, CLOTHES, SPORTS;
}
