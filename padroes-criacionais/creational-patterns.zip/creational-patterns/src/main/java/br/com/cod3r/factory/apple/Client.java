package br.com.cod3r.factory.apple;

public class Client {
	
	public static void main(String[] args) {
		
		System.out.println("### Ordering an iPhone X");
		
		System.out.println("\n\n### Ordering an iPhone 11 HighEnd");
	}
}
