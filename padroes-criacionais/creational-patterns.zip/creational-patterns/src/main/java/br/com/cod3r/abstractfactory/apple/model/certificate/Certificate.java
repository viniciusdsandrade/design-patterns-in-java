package br.com.cod3r.abstractfactory.apple.model.certificate;

public interface Certificate {
	String applyCertification();
}
