package br.com.cod3r.factory.app.dbadapter;

public class Client {

	public static void main(String[] args) {

	}
}
