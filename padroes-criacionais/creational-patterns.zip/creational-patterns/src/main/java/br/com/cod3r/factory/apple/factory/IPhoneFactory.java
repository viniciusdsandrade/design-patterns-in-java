package br.com.cod3r.factory.apple.factory;

public abstract class IPhoneFactory {

	
}
