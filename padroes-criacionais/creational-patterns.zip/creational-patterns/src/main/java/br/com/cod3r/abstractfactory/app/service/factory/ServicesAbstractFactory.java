package br.com.cod3r.abstractfactory.app.service.factory;

public interface ServicesAbstractFactory {

}
