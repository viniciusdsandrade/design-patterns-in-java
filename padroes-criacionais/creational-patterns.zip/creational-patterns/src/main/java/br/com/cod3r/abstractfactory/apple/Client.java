package br.com.cod3r.abstractfactory.apple;

public class Client {
	
	public static void main(String[] args) {

	}
}
