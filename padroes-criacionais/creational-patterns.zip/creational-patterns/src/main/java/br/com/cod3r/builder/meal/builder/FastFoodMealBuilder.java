package br.com.cod3r.builder.meal.builder;

public abstract class FastFoodMealBuilder {
	
}
