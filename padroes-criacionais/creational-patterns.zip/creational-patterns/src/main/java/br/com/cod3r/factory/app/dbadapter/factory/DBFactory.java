package br.com.cod3r.factory.app.dbadapter.factory;

import br.com.cod3r.factory.app.dbadapter.db.DB;

public interface DBFactory {
	DB getDatabase();
}
