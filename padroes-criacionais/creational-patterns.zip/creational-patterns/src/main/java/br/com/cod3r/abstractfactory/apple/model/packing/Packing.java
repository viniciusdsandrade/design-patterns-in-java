package br.com.cod3r.abstractfactory.apple.model.packing;

public interface Packing {

	String pack();
}
