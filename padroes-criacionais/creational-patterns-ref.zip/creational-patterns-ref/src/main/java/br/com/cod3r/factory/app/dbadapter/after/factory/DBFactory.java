package br.com.cod3r.factory.app.dbadapter.after.factory;

import br.com.cod3r.factory.app.dbadapter.after.db.DB;

public interface DBFactory {
	DB getDatabase();
}
