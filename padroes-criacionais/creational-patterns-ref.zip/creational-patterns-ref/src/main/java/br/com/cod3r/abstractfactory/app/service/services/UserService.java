package br.com.cod3r.abstractfactory.app.service.services;

public interface UserService {
	void save(String name);
	boolean delete(Integer id);
}
