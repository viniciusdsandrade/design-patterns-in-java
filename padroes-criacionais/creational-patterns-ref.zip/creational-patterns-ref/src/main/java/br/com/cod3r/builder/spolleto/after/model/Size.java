package br.com.cod3r.builder.spolleto.after.model;

public enum Size {
	SMALL, STANDARD, LARGE;
}
