package br.com.cod3r.abstractfactory.apple.model.packing;

public class USPacking implements Packing {

	public String pack() {
		return "\t- Packing in English";
	}

}
