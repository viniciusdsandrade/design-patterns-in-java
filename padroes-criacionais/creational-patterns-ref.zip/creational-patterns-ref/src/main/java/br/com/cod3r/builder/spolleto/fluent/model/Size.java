package br.com.cod3r.builder.spolleto.fluent.model;

public enum Size {
	SMALL, STANDARD, LARGE;
}
