package br.com.cod3r.builder.spolleto.before.model;

public enum Size {
	SMALL, STANDARD, LARGE;
}
