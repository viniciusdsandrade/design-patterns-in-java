package br.com.cod3r.mediator.translate.model;

public enum Language {
	PORTUGUESE, ENGLISH;
}
