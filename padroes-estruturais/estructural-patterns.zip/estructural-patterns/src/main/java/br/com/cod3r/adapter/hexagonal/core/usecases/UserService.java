package br.com.cod3r.adapter.hexagonal.core.usecases;

public class UserService {
	
}
