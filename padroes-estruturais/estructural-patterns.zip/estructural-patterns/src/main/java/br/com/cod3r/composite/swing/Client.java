package br.com.cod3r.composite.swing;

public class Client {

	public static void main(String[] args) {
		
	}
}
