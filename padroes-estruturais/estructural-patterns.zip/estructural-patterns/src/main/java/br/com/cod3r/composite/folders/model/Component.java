package br.com.cod3r.composite.folders.model;

public interface Component {
	
}
