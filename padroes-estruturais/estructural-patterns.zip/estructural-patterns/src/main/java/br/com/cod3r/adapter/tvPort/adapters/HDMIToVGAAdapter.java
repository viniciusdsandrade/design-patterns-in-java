package br.com.cod3r.adapter.tvPort.adapters;

public class HDMIToVGAAdapter {

}
