package br.com.cod3r.proxy.remoteResource.services;

public interface Resource {
	String getData();
}
