package br.com.cod3r.adapter.hexagonal.core.ports;

public interface UserRepository {
	
}
