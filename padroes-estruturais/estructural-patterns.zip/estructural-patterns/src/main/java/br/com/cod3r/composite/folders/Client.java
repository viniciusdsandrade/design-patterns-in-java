package br.com.cod3r.composite.folders;

public class Client {

	public static void main(String[] args) {
		
	}
}
