package br.com.cod3r.bridge.mvc;

import br.com.cod3r.bridge.mvc.model.User;

public class Client {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		User user = new User("user", "user@email.com", "passwd");
		
		
	}
}
