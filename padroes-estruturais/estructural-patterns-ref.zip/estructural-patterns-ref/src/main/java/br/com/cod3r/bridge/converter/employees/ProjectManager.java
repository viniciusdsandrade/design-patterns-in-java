package br.com.cod3r.bridge.converter.employees;

public class ProjectManager extends Employee {

	public ProjectManager(String name, Integer age, Double salary) {
		super(name, age, salary);
	}

}
