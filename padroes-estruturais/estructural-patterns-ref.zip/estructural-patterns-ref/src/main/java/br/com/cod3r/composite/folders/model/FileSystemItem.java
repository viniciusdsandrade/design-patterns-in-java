package br.com.cod3r.composite.folders.model;

public interface FileSystemItem {
	void print(String structure);
}
