package br.com.cod3r.adapter.tvPort.intefaces;

public interface HDMI {
	void setImage(String image);
	void setSound(String sound);
}
