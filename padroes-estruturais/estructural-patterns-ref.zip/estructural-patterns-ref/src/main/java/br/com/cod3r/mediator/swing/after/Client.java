package br.com.cod3r.mediator.swing.after;

public class Client {
	
	public static void main(String[] args) {
		Screens screens = new Screens();
		screens.init();
	}
}
