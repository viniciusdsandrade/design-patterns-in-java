package br.com.cod3r.adapter.tvPort.intefaces;

public interface VGA {
	public void setImage(String image);
}
